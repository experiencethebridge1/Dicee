package com.experiencethebridge1.dicee;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /** Define variables/assign, cast if needed.
         * Linking elements from xml to Java code
         * */

        Button rollButton;
        // Assign variable and cast
        rollButton = findViewById(R.id.rollButton);

        final ImageView leftDice;
        leftDice = findViewById(R.id.image_leftDice);

        final ImageView rightDice;
        rightDice = findViewById(R.id.image_rightDice);

        // create the diceArray
        final int[] diceArray = {R.drawable.dice1,
                R.drawable.dice2,
                R.drawable.dice3,
                R.drawable.dice4,
                R.drawable.dice5,
                R.drawable.dice6};

        // Set listener
        rollButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // activates each time the roll button is pressed.
                Log.d("Dicee", "Ze button has been pressed!");

                // Create random numbers for dice
                Random randomNumberGeneratorLeft = new Random();
                int numberLeft = randomNumberGeneratorLeft.nextInt(6);

                Random randomNumberGeneratorRight = new Random();
                int numberRight = randomNumberGeneratorRight.nextInt(6);

                // Test Random number generator using Log.d
                Log.d("Dicee", "The random element number for the Left Dice is: " + numberLeft);
                Log.d("Dicee", "The random element number for the Right Dice is: " + numberRight);

                // set images inside of the on-click listner
                leftDice.setImageResource(diceArray[numberLeft]);
                rightDice.setImageResource(diceArray[numberRight]);

            }
        });

    }
}
